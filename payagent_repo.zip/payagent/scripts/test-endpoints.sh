#!/bin/bash
# PayAgent — HTTPS endpoint verification
BASE="https://payagent.yourdomain.com"

echo "=== PayAgent HTTPS Endpoint Tests ==="

check() {
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X "$2" "$BASE$1" \
    -H "Authorization: Bearer $TEST_TOKEN" \
    -H "Content-Type: application/json")
  if [ "$STATUS" = "$3" ]; then
    echo "✅  $2 $1 → $STATUS"
  else
    echo "❌  $2 $1 → $STATUS (expected $3)"
  fi
}

check "/api/health"              GET  200
check "/api/generate_apass"      POST 401   # no token = 401
check "/api/atoken/register"     POST 401
check "/api/validator/register"  POST 401

echo ""
echo "=== SSL Check ==="
echo | openssl s_client -connect payagent.yourdomain.com:443 \
  -servername payagent.yourdomain.com 2>/dev/null \
  | openssl x509 -noout -dates

echo ""
echo "=== HSTS Header ==="
curl -sI https://payagent.yourdomain.com | grep -i strict-transport
